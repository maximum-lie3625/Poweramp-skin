package com.poweramp.v3.skins.applemusic

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class SkinInfoActivity : Activity() {

    companion object {
        const val POWERAMP_PACKAGE = "com.maxmpz.audioplayer"
        const val EXTRA_SKIN_PACKAGE = "pak"
        const val EXTRA_SKIN_STYLE = "style"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            setBackgroundColor(0xFF121216.toInt())
        }

        val titleView = TextView(this).apply {
            text = getString(R.string.skin_name_dark)
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        val descView = TextView(this).apply {
            text = getString(R.string.skin_description)
            textSize = 14f
            setTextColor(0xFFB0B0B8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 48)
        }

        val applyDarkBtn = Button(this).apply {
            text = "Apply Cupertino Dynamic Dark Skin"
            setOnClickListener { applySkin(R.style.AppleMusicSkin) }
        }

        val applyLightBtn = Button(this).apply {
            text = "Apply Cupertino Light Skin"
            setOnClickListener { applySkin(R.style.AppleMusicSkinLight) }
        }

        val openSettingsBtn = Button(this).apply {
            text = "Open Skin Options in Poweramp"
            setOnClickListener { openPowerampThemeSettings() }
        }

        root.addView(titleView)
        root.addView(descView)
        root.addView(applyDarkBtn)
        root.addView(applyLightBtn)
        root.addView(openSettingsBtn)

        setContentView(root)
    }

    private fun applySkin(styleResId: Int) {
        try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                setClassName(POWERAMP_PACKAGE, "$POWERAMP_PACKAGE.StartupActivity")
                putExtra(EXTRA_SKIN_PACKAGE, packageName)
                putExtra(EXTRA_SKIN_STYLE, styleResId)
                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Poweramp v3 not found on device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openPowerampThemeSettings() {
        try {
            val intent = Intent().apply {
                setClassName(POWERAMP_PACKAGE, "$POWERAMP_PACKAGE.preference.SettingsActivity")
                putExtra("open", "theme")
                putExtra(EXTRA_SKIN_PACKAGE, packageName)
                putExtra(EXTRA_SKIN_STYLE, R.style.AppleMusicSkin)
            }
            startActivityForResult(intent, 1001)
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open Poweramp settings", Toast.LENGTH_SHORT).show()
        }
    }
}
