# Apple Music (Cupertino) Skin for Poweramp v3 — Android Studio SDK Project

This project is a complete, ready-to-compile **Poweramp v3 Skin APK** template built on the official [Poweramp v3 Skin SDK (`poweramp_skin_sample`)](https://github.com/maxmpz/powerampapi/tree/master/poweramp_skin_sample).

It implements an **Apple Music-inspired ("Cupertino / Zenith") UI** for Poweramp v3 (targeting Build 1003–1007+), featuring:
- **Floating Rounded Album Art (`scene_aa`)** with user-adjustable corner radius (`0dp` to `36dp`, default `16dp`) and elevation shadow.
- **Dynamic Blurred Artwork Background**, **Clean Light Mode (`lightMode`)**, and **Pure AMOLED Dark Mode** overlap styles.
- **Apple Music Typography & Left-Aligned Track Metadata** using Poweramp's `eatFontPads="true"` and `layout_alignToContent="true"` FastTextView alignment.
- **Minimalist Pill Seekbar & Optional Static Waveform (`TopWave`)** switcher in skin settings.
- **Clean Bottom Transport Controls & Configurable `TopSubAAButtons`** compatible with Poweramp Build 1003+ editable button bars.

---

## Project Structure

```text
poweramp_apple_music_skin_sdk/
├── build.gradle
├── settings.gradle
├── local.properties.example
└── app/
    ├── build.gradle
    ├── stable-ids.txt
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/poweramp/v3/skins/applemusic/
        │   └── SkinInfoActivity.kt
        └── res/
            ├── drawable/
            │   ├── bg_apple_glass_pill.xml
            │   ├── ic_apple_pause.xml
            │   ├── ic_apple_play.xml
            │   ├── ic_apple_next.xml
            │   ├── ic_apple_prev.xml
            │   └── seekbar_apple_minimal.xml
            ├── values/
            │   ├── apple_music_skin_styles.xml
            │   ├── attrs.xml
            │   ├── colors.xml
            │   └── strings.xml
            └── xml/
                └── skins.xml
```

---

## How to Build & Test in Android Studio

1. **Clone the Official Reference Resources**:
   - Download or clone the official [maxmpz/powerampapi](https://github.com/maxmpz/powerampapi) repository.
   - Copy this project's files into a copy of `poweramp_skin_sample`, or copy the bundled `reference_resources/poweramp_resources.apk` into `reference_resources/` at the root of this project.
2. **Open in Android Studio**:
   - Open the project folder in Android Studio.
   - Ensure `local.properties` points to your Android SDK (`sdk.dir=...`) and optionally to your reference Poweramp APK (`poweramp.apk=reference_resources/poweramp_resources.apk`).
3. **Enable Live Skin Reloading on Your Phone**:
   - On your Android phone with Poweramp v3 installed, go to **Poweramp Settings > Misc > Always Reload Skin** and enable it.
   - Do **not** use Android Studio's "Apply Changes" button (it does not reload external skin resources properly); always use **Run 'app'** (`Shift+F10`).
4. **Apply the Skin**:
   - Launch the compiled **Cupertino Skin for Poweramp** app on your device and tap **"Apply Apple Music Skin in Poweramp"**, or select it under **Poweramp Settings > Look and Feel > Skin**.

---

## How to Build the APK on Your Phone (No Computer Needed — GitHub Actions)

1. Open [github.com](https://github.com/) in your mobile browser (Chrome/Safari) and tap **New Repository** (name it `poweramp-apple-music-skin`).
2. Tap **uploading an existing file** and upload the unzipped files from this archive (making sure `.github/workflows/build-skin-apk.yml` and the `app/` folder are included).
3. Tap the **Actions** tab at the top of your GitHub repository and run **Build Poweramp Apple Music Skin APK**.
4. In ~2 minutes, scroll down to **Artifacts** on that workflow page and tap **Cupertino-Apple-Music-Poweramp-Skin-APK** to download the compiled `.apk` directly to your phone!
